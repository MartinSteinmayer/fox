/**
 * Tab Whisperer — Background Script (Orchestrator)
 *
 * This is the main entry point. It:
 * 1. Handles messages from the popup (text commands)
 * 2. Manages WebSocket connection to the voice server
 * 3. Dispatches commands through the LLM tool-calling loop
 * 4. Manages extension state and badge
 */

(function () {
  "use strict";

  // ─── State ─────────────────────────────────────────────────

  const THIRTY_DAYS_MS = 30 * 24 * 60 * 60 * 1000;

  const state = {
    wsConnected: false,
    processing: false,
    voiceListening: false,
    ws: null,
    popupPort: null, // Long-lived connection to popup
    actionLog: [], // History of actions for display (persisted)
    currentCommand: null, // In-progress command: { command, toolCalls[], startedAt }
  };

  // ─── Persistent Action Log ──────────────────────────────

  async function loadActionLog() {
    const { actionLog } = await browser.storage.local.get({ actionLog: [] });
    const cutoff = Date.now() - THIRTY_DAYS_MS;
    state.actionLog = actionLog.filter((e) => e.timestamp > cutoff);
  }

  async function saveActionLog() {
    // Keep max 500 entries and prune >30 days
    const cutoff = Date.now() - THIRTY_DAYS_MS;
    state.actionLog = state.actionLog
      .filter((e) => e.timestamp > cutoff)
      .slice(-500);
    await browser.storage.local.set({ actionLog: state.actionLog });
  }

  // ─── Settings Defaults ───────────────────────────────────

  const SETTINGS_DEFAULTS = {
    apiKey: "",
    provider: "openai",
    model: "gpt-5-mini",
    temperature: 1,
    maxTokens: 10000,
    openaiBaseUrl: "https://api.openai.com/v1",
    ollamaBaseUrl: "http://localhost:11434/v1",
    voiceServerUrl: "ws://localhost:8765",
    wakeWord: "hey fox",
  };

  // ─── Badge & Status ──────────────────────────────────────

  function setBadge(text, color) {
    browser.browserAction.setBadgeText({ text });
    browser.browserAction.setBadgeBackgroundColor({ color });
  }

  function updateStatus(status) {
    // Status: "idle" | "listening" | "processing" | "error"
    switch (status) {
      case "idle":
        setBadge("", "#6366f1");
        break;
      case "listening":
        setBadge("MIC", "#22c55e");
        break;
      case "processing":
        setBadge("...", "#f59e0b");
        break;
      case "error":
        setBadge("ERR", "#ef4444");
        break;
    }

    // Notify popup if connected
    sendToPopup({ type: "status", status, wsConnected: state.wsConnected });
  }

  // ─── Popup Communication ─────────────────────────────────

  function sendToPopup(message) {
    if (state.popupPort) {
      try {
        state.popupPort.postMessage(message);
      } catch (e) {
        // Port disconnected
        state.popupPort = null;
      }
    }
  }

  // Handle long-lived connections from popup
  browser.runtime.onConnect.addListener((port) => {
    if (port.name === "popup") {
      state.popupPort = port;

      // Send current state immediately
      port.postMessage({
        type: "init",
        status: state.processing
          ? "processing"
          : state.voiceListening
            ? "listening"
            : "idle",
        wsConnected: state.wsConnected,
        actionLog: state.actionLog.slice(-50), // Last 50 entries
        currentCommand: state.currentCommand, // In-progress command (null if idle)
      });

      port.onDisconnect.addListener(() => {
        state.popupPort = null;
      });

      port.onMessage.addListener(handlePopupMessage);
    }
  });

  // Handle one-shot messages (fallback for simple requests)
  browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "get_status") {
      sendResponse({
        status: state.processing
          ? "processing"
          : state.voiceListening
            ? "listening"
            : "idle",
        wsConnected: state.wsConnected,
      });
      return false;
    }

    if (message.type === "execute_command") {
      handleCommand(message.text).then(sendResponse);
      return true; // Keep channel open for async response
    }

    return false;
  });

  // ─── Command Handling ────────────────────────────────────

  async function handlePopupMessage(message) {
    switch (message.type) {
      case "command":
        await handleCommand(message.text);
        break;
      case "cancel":
        // TODO: implement cancellation
        break;
      case "reconnect_ws":
        connectWebSocket();
        break;
      case "get_history":
        sendToPopup({ type: "history", entries: state.actionLog });
        break;
      case "clear_history":
        state.actionLog = [];
        saveActionLog();
        sendToPopup({ type: "history", entries: [] });
        break;
    }
  }

  /**
   * Main command handler. Takes a text command, runs it through the
   * LLM tool-calling loop, and returns the result.
   */
  async function handleCommand(text) {
    if (state.processing) {
      sendToPopup({
        type: "error",
        message: "Already processing a command. Please wait.",
      });
      return { error: "Already processing a command." };
    }

    state.processing = true;
    updateStatus("processing");

    // Track in-progress command in state (survives popup close/reopen)
    state.currentCommand = {
      command: text,
      toolCalls: [],
      startedAt: Date.now(),
    };

    sendToPopup({ type: "command_start", command: text });

    try {
      const result = await ToolExecutor.execute(text, (type, data) => {
        // Forward progress updates to popup
        sendToPopup({ type: "progress", progressType: type, ...data });

        // Track tool calls in currentCommand (with timestamps)
        if (type === "tool_call") {
          state.currentCommand.toolCalls.push({
            name: data.name,
            args: data.args,
            result: null, // filled in on tool_result
            timestamp: Date.now(),
          });
        }

        // Attach result to the most recent matching tool call
        if (type === "tool_result") {
          const pending = state.currentCommand.toolCalls;
          for (let i = pending.length - 1; i >= 0; i--) {
            if (pending[i].name === data.name && pending[i].result === null) {
              pending[i].result = data.result;
              break;
            }
          }
        }
      });

      // Build final log entry from currentCommand + result
      const logEntry = {
        id: state.currentCommand.startedAt.toString(),
        timestamp: state.currentCommand.startedAt,
        command: text,
        toolCalls: state.currentCommand.toolCalls,
        response: result.response,
        error: result.error || null,
      };

      sendToPopup({
        type: "command_complete",
        response: result.response,
        toolCalls: state.currentCommand.toolCalls,
        error: result.error,
      });

      // Show notification if popup is closed
      if (!state.popupPort) {
        const notifMessage = result.response
          ? result.response.substring(0, 200)
          : result.error || "Command completed";

        browser.notifications.create({
          type: "basic",
          title: "Tab Whisperer",
          message: notifMessage,
          iconUrl: browser.runtime.getURL("icons/icon-48.png"),
        });
      }

      // Save to action log (persisted)
      state.actionLog.push(logEntry);
      saveActionLog();

      return result;
    } catch (err) {
      const errorMsg = `Error: ${err.message}`;

      sendToPopup({
        type: "command_complete",
        response: null,
        error: errorMsg,
      });

      // Save error to action log
      state.actionLog.push({
        id: state.currentCommand.startedAt.toString(),
        timestamp: state.currentCommand.startedAt,
        command: text,
        toolCalls: state.currentCommand.toolCalls,
        response: null,
        error: errorMsg,
      });
      saveActionLog();

      return { error: errorMsg };
    } finally {
      state.processing = false;
      state.currentCommand = null;
      updateStatus("idle");
    }
  }

  // ─── WebSocket (Voice Server) ────────────────────────────

  async function connectWebSocket() {
    // Close existing connection
    if (state.ws) {
      try {
        state.ws.close();
      } catch (e) {}
      state.ws = null;
    }

    const settings = await browser.storage.local.get(SETTINGS_DEFAULTS);
    const url = settings.voiceServerUrl;

    console.log(`[WS] Connecting to ${url}...`);

    try {
      const ws = new WebSocket(url);
      state.ws = ws;

      ws.onopen = () => {
        console.log("[WS] Connected to voice server");
        state.wsConnected = true;
        sendToPopup({ type: "ws_status", connected: true });
        updateStatus("idle");
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          handleVoiceMessage(msg);
        } catch (e) {
          console.warn("[WS] Invalid message:", event.data);
        }
      };

      ws.onclose = () => {
        console.log("[WS] Disconnected from voice server");
        state.wsConnected = false;
        state.voiceListening = false;
        state.ws = null;
        sendToPopup({ type: "ws_status", connected: false });
        updateStatus("idle");

        // Auto-reconnect after 5 seconds
        setTimeout(connectWebSocket, 5000);
      };

      ws.onerror = (err) => {
        console.warn("[WS] Error:", err);
        // onclose will fire after this
      };
    } catch (err) {
      console.warn("[WS] Failed to connect:", err);
      state.wsConnected = false;
      // Retry after 5 seconds
      setTimeout(connectWebSocket, 5000);
    }
  }

  function handleVoiceMessage(msg) {
    console.log("[WS] Voice message:", msg);

    switch (msg.type) {
      case "wake":
        state.voiceListening = true;
        updateStatus("listening");
        sendToPopup({ type: "voice_wake" });
        break;

      case "listening":
        state.voiceListening = true;
        updateStatus("listening");
        sendToPopup({ type: "voice_listening" });
        break;

      case "command":
        state.voiceListening = false;
        if (msg.text) {
          // Show the transcribed text in popup as a user message
          sendToPopup({ type: "voice_command", text: msg.text });

          // Run the command and send ack back to voice server
          handleCommand(msg.text).then((result) => {
            sendToVoiceServer({
              type: "ack",
              result: result.response || result.error || "done",
            });
          });
        }
        break;

      case "error":
        state.voiceListening = false;
        updateStatus("error");
        sendToPopup({ type: "voice_error", message: msg.message });
        break;

      case "status":
        sendToPopup({ type: "voice_status", ...msg });
        break;
    }
  }

  function sendToVoiceServer(msg) {
    if (state.ws && state.ws.readyState === WebSocket.OPEN) {
      state.ws.send(JSON.stringify(msg));
    }
  }

  // ─── Settings Sync ──────────────────────────────────────

  // Forward wake word changes to voice server when settings are updated
  browser.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.wakeWord && changes.wakeWord.newValue) {
      sendToVoiceServer({
        type: "config",
        wake_word: changes.wakeWord.newValue,
      });
      console.log(
        `[TabWhisperer] Wake word updated to: ${changes.wakeWord.newValue}`,
      );
    }
  });

  // ─── Keyboard Shortcuts ──────────────────────────────────

  browser.commands.onCommand.addListener((command) => {
    if (command === "toggle-listening") {
      if (state.voiceListening) {
        sendToVoiceServer({ type: "stop_listening" });
        state.voiceListening = false;
        updateStatus("idle");
      } else {
        sendToVoiceServer({ type: "start_listening" });
        state.voiceListening = true;
        updateStatus("listening");
      }
    }
  });

  // ─── Initialization ──────────────────────────────────────

  browser.runtime.onInstalled.addListener(async ({ reason }) => {
    if (reason === "install") {
      console.log("[TabWhisperer] First install — setting defaults");
      await browser.storage.local.set(SETTINGS_DEFAULTS);
    }
  });

  // Initialize on startup
  async function init() {
    console.log("[TabWhisperer] Background script starting...");
    updateStatus("idle");

    // Load persisted action log
    await loadActionLog();
    console.log(
      `[TabWhisperer] Loaded ${state.actionLog.length} action log entries`,
    );

    // Check if API key is configured
    const settings = await browser.storage.local.get(SETTINGS_DEFAULTS);
    if (!settings.apiKey && settings.provider === "openai") {
      console.warn("[TabWhisperer] No API key configured. Set one in options.");
      setBadge("KEY", "#ef4444");
    }

    // Try to connect to voice server (non-blocking)
    connectWebSocket();
  }

  init();
})();
