/**
 * Tab Whisperer — Popup Script (Voice-First + History)
 * 
 * Minimalist voice-driven UI with microphone animations, tool call display, and history panel.
 */

(function () {
  "use strict";

  // ─── DOM Elements ──────────────────────────────────────

  const btnSettings = document.getElementById("btn-settings");
  const micIcon = document.getElementById("mic-icon");
  const commandText = document.getElementById("command-text");
  const toolArea = document.getElementById("tool-area");
  const historyList = document.getElementById("history-list");
  const historyCount = document.getElementById("history-count");
  const btnClearHistory = document.getElementById("btn-clear-history");
  const textInput = document.getElementById("text-input");
  const btnSend = document.getElementById("btn-send");

  // ─── State ─────────────────────────────────────────────

  let port = null;
  let currentState = "idle"; // idle | wake | listening | processing | error
  let toolCallIndex = 0; // Counter for tagging tool call divs

  // ─── Connect to Background ────────────────────────────

  function connect() {
    port = browser.runtime.connect({ name: "popup" });

    port.onMessage.addListener(handleBackgroundMessage);

    port.onDisconnect.addListener(() => {
      port = null;
      setTimeout(connect, 500);
    });
  }

  function handleBackgroundMessage(msg) {
    switch (msg.type) {
      case "init":
        // Restore state from background — force update (bypass same-state check)
        currentState = "__init__";
        if (msg.currentCommand) {
          // Mid-processing: replay in-progress tool calls immediately
          clearToolArea();
          showCommand(msg.currentCommand.command);
          for (const tc of msg.currentCommand.toolCalls) {
            addToolCall(tc.name, tc.args, tc.result);
          }
          // Show tools immediately (no transition delay on restore)
          micIcon.style.display = "none";
          micIcon.className = "mic-icon";
          toolArea.classList.add("active");
          currentState = "processing";
        } else {
          // Idle or listening — fresh mic state, no stale tools
          clearToolArea();
          setState(msg.status === "listening" ? "listening" : "idle");
        }
        // Render history
        if (msg.actionLog) {
          renderHistory(msg.actionLog);
        }
        break;

      case "history":
        renderHistory(msg.entries || []);
        break;

      case "status":
        if (msg.status === "idle") setState("idle");
        else if (msg.status === "processing") setState("processing");
        else if (msg.status === "error") setState("error");
        break;

      case "command_start":
        // New command starting — show command text, clear old tools, enter processing
        clearToolArea();
        showCommand(msg.command);
        setState("processing");
        break;

      case "progress":
        handleProgress(msg);
        break;

      case "command_complete":
        // Transition to idle but KEEP tool area visible until next command
        setState("idle");

        // Refresh history to include the new entry
        if (port) {
          port.postMessage({ type: "get_history" });
        }
        break;

      case "voice_wake":
        setState("wake");
        // Clear tool area — new voice session starting
        clearToolArea();
        break;

      case "voice_listening":
        setState("listening");
        break;

      case "voice_command":
        // Transcription received — command_start will handle the transition
        break;

      case "voice_error":
        setState("error");
        setTimeout(() => setState("idle"), 2000);
        break;

      case "error":
        setState("error");
        setTimeout(() => setState("idle"), 2000);
        break;
    }
  }

  function handleProgress(msg) {
    switch (msg.progressType) {
      case "tool_call":
        // Show tool call in the tool area (pending result)
        addToolCall(msg.name, msg.args, null);
        break;

      case "tool_result":
        // Update the matching tool call with its result
        updateToolResult(msg.name, msg.result);
        break;

      // Ignore thinking, response, and error messages
      case "thinking":
      case "response":
      case "error":
        break;
    }
  }

  // ─── State Management ──────────────────────────────────

  function setState(newState) {
    if (currentState === newState) return;
    currentState = newState;

    if (newState === "processing") {
      // Hide mic immediately, show tool area after brief delay
      micIcon.style.display = "none";
      micIcon.className = "mic-icon";
      setTimeout(() => {
        toolArea.classList.add("active");
      }, 100);
    } else if (newState === "idle") {
      if (toolArea.children.length > 0) {
        // Tool results visible — keep them + command text, mic stays hidden
        micIcon.style.display = "none";
        micIcon.className = "mic-icon";
        toolArea.classList.add("active");
      } else {
        // No tools — show mic, hide tool area + command text
        toolArea.classList.remove("active");
        commandText.classList.remove("active");
        micIcon.style.display = "";
        micIcon.className = "mic-icon idle";
      }
    } else if (newState === "wake" || newState === "listening") {
      // Voice session — show mic animation, hide tool area + command text
      toolArea.classList.remove("active");
      commandText.classList.remove("active");
      micIcon.style.display = "";
      micIcon.className = `mic-icon ${newState}`;
    } else if (newState === "error") {
      micIcon.style.display = "";
      micIcon.className = "mic-icon error";
    }
  }

  // ─── Tool Area Management ──────────────────────────────

  function clearToolArea() {
    toolArea.innerHTML = "";
    toolCallIndex = 0;
    commandText.textContent = "";
    commandText.classList.remove("active");
  }

  /**
   * Show the command text in the green box above tool calls.
   */
  function showCommand(text) {
    if (!text) return;
    commandText.textContent = `"${text}"`;
    commandText.classList.add("active");
  }

  /**
   * Add a tool call to the display area.
   * @param {string} name - Tool name
   * @param {object} args - Tool arguments
   * @param {*} result - Tool result (null if pending)
   */
  function addToolCall(name, args, result) {
    const div = document.createElement("div");
    div.className = "tool-call";
    div.dataset.toolIndex = toolCallIndex++;
    div.dataset.toolName = name;

    const header = document.createElement("div");
    header.className = "tool-header";

    const nameSpan = document.createElement("span");
    nameSpan.className = "tool-name";
    nameSpan.textContent = name;
    header.appendChild(nameSpan);

    // Status indicator
    const statusSpan = document.createElement("span");
    statusSpan.className = "tool-status";
    if (result !== null && result !== undefined) {
      const isError = result && result.error;
      statusSpan.textContent = isError ? "FAIL" : "OK";
      statusSpan.classList.add(isError ? "fail" : "ok");
    } else {
      statusSpan.textContent = "...";
      statusSpan.classList.add("pending");
    }
    header.appendChild(statusSpan);

    div.appendChild(header);

    if (args && Object.keys(args).length > 0) {
      const argsDiv = document.createElement("div");
      argsDiv.className = "tool-args";
      
      // Format args concisely
      const argsStr = Object.entries(args)
        .map(([k, v]) => {
          const val = Array.isArray(v) ? `[${v.length} items]` : JSON.stringify(v);
          return `${k}: ${val}`;
        })
        .join(", ");
      
      argsDiv.textContent = argsStr;
      div.appendChild(argsDiv);
    }

    toolArea.appendChild(div);

    // Auto-scroll to bottom
    toolArea.scrollTop = toolArea.scrollHeight;
  }

  /**
   * Update the most recent matching tool call div with its result.
   */
  function updateToolResult(name, result) {
    // Find the last tool call div matching this name that's still pending
    const allCalls = toolArea.querySelectorAll(".tool-call");
    for (let i = allCalls.length - 1; i >= 0; i--) {
      const div = allCalls[i];
      const status = div.querySelector(".tool-status");
      if (div.dataset.toolName === name && status && status.classList.contains("pending")) {
        const isError = result && result.error;
        status.textContent = isError ? "FAIL" : "OK";
        status.classList.remove("pending");
        status.classList.add(isError ? "fail" : "ok");
        break;
      }
    }
  }

  // ─── History Rendering ─────────────────────────────────

  function renderHistory(entries) {
    historyList.innerHTML = "";
    historyCount.textContent = entries.length;

    // Show most recent first
    const sorted = [...entries].reverse();

    for (const entry of sorted) {
      historyList.appendChild(renderHistoryEntry(entry));
    }
  }

  function renderHistoryEntry(entry) {
    const details = document.createElement("details");
    details.className = "history-entry";

    const time = new Date(entry.timestamp).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    const commandText = entry.command || "(voice command)";
    const hasError = !!entry.error;

    // Summary line
    const summary = document.createElement("summary");
    const timeSpan = document.createElement("span");
    timeSpan.className = "entry-time";
    timeSpan.textContent = time;
    summary.appendChild(timeSpan);
    const cmdSpan = document.createElement("span");
    cmdSpan.className = "entry-command";
    cmdSpan.textContent = commandText;
    summary.appendChild(cmdSpan);
    if (hasError) {
      const errSpan = document.createElement("span");
      errSpan.className = "entry-error-badge";
      errSpan.textContent = "ERR";
      summary.appendChild(errSpan);
    }
    details.appendChild(summary);

    // Expanded body
    const body = document.createElement("div");
    body.className = "entry-body";

    // Tool calls section
    if (entry.toolCalls && entry.toolCalls.length > 0) {
      const label = document.createElement("div");
      label.className = "entry-section-label";
      label.textContent = `Tools (${entry.toolCalls.length})`;
      body.appendChild(label);

      for (const tc of entry.toolCalls) {
        const toolDiv = document.createElement("div");
        toolDiv.className = "entry-tool";

        const nameSpan = document.createElement("span");
        nameSpan.className = "entry-tool-name";
        nameSpan.textContent = tc.name;
        toolDiv.appendChild(nameSpan);

        if (tc.args && Object.keys(tc.args).length > 0) {
          const argsDiv = document.createElement("div");
          argsDiv.className = "entry-tool-args";
          argsDiv.textContent = JSON.stringify(tc.args, null, 2);
          toolDiv.appendChild(argsDiv);
        }

        if (tc.result !== undefined && tc.result !== null) {
          const resultStr = typeof tc.result === "string"
            ? tc.result
            : JSON.stringify(tc.result, null, 2);
          const truncated = resultStr.length > 300
            ? resultStr.substring(0, 300) + "..."
            : resultStr;
          const resultDiv = document.createElement("div");
          resultDiv.className = "entry-tool-result";
          resultDiv.textContent = truncated;
          toolDiv.appendChild(resultDiv);
        }

        body.appendChild(toolDiv);
      }
    }

    // Response section
    if (entry.response) {
      const label = document.createElement("div");
      label.className = "entry-section-label";
      label.textContent = "Response";
      body.appendChild(label);

      const resp = document.createElement("div");
      resp.className = "entry-response";
      resp.textContent = entry.response;
      body.appendChild(resp);
    }

    // Error section
    if (entry.error) {
      const errDiv = document.createElement("div");
      errDiv.className = "entry-error";
      errDiv.textContent = entry.error;
      body.appendChild(errDiv);
    }

    details.appendChild(body);
    return details;
  }

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  // ─── Text Input ────────────────────────────────────────

  function sendTextCommand() {
    const text = textInput.value.trim();
    if (!text || !port) return;
    textInput.value = "";
    port.postMessage({ type: "command", text });
  }

  // ─── Event Listeners ──────────────────────────────────

  btnSettings.addEventListener("click", () => {
    browser.runtime.openOptionsPage();
  });

  btnClearHistory.addEventListener("click", (e) => {
    e.preventDefault();
    e.stopPropagation(); // Don't toggle the <details> panel
    if (port) {
      port.postMessage({ type: "clear_history" });
    }
  });

  textInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendTextCommand();
    }
  });

  btnSend.addEventListener("click", () => {
    sendTextCommand();
  });

  // ─── Init ─────────────────────────────────────────────

  connect();
  // Set initial visual state (mic visible, tool area hidden)
  // The actual state will be set by the 'init' message from background
  micIcon.style.display = "";
  micIcon.className = "mic-icon idle";

})();
